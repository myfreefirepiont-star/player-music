package com.example.playermusic

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val Bg = Color(0xFF090710)
private val Panel = Color(0xFF171323)
private val Purple = Color(0xFF9B5CFF)
private val Pink = Color(0xFFE05BFF)
private val Muted = Color(0xFFB9B1C9)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : androidx.fragment.app.FragmentActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { PlayerMusicApp(player!!) }
    }
    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun PlayerMusicApp(player: ExoPlayer) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("player_music", 0) }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var privateTracks by remember { mutableStateOf<List<File>>(emptyList()) }
    var activeTrack by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var secretUnlocked by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var newPinMode by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var playlistNames by remember { mutableStateOf(prefs.getStringSet("playlists", emptySet())?.toList() ?: emptyList()) }
    var hiddenIds by remember { mutableStateOf(prefs.getStringSet("hidden_ids", emptySet()) ?: emptySet()) }
    var permissionGranted by remember { mutableStateOf(hasAudioPermission(context)) }
    var statusText by remember { mutableStateOf("برای ورود به فضای مخفی، دو انگشت را در جهت مخالف بالا و پایین بکش") }

    fun refreshPrivate() {
        privateTracks = File(context.filesDir, "secret").listFiles()?.filter { it.isFile } ?: emptyList()
    }
    suspend fun scanTracks() {
        tracks = withContext(Dispatchers.IO) {
            val list = mutableListOf<Track>()
            val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST
            )
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
            context.contentResolver.query(collection, projection, selection, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor: Cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    list.add(Track(id, cursor.getString(titleCol) ?: "آهنگ بی‌نام",
                        cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "هنرمند ناشناس",
                        ContentUris.withAppendedId(collection, id)))
                }
            }
            list
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) {
            kotlinx.coroutines.MainScope().launch { scanTracks() }
        } else statusText = "برای دیدن آهنگ‌های گوشی، مجوز فایل صوتی لازم است."
    }

    LaunchedEffect(Unit) {
        refreshPrivate()
        if (permissionGranted) scanTracks()
        else permissionLauncher.launch(audioPermission())
    }

    fun play(track: Track) {
        activeTrack = track
        player.setMediaItem(MediaItem.fromUri(track.uri))
        player.prepare()
        player.play()
        isPlaying = true
    }

    fun unlockWithBiometric() {
        val activity = context as? FragmentActivity
        if (activity == null) {
            showPinDialog = true
            return
        }
        val manager = BiometricManager.from(context)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            != BiometricManager.BIOMETRIC_SUCCESS) {
            showPinDialog = true
            return
        }
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(context),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    secretUnlocked = true
                    showPinDialog = false
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    statusText = "برای ورود می‌توانی رمز را وارد کنی."
                    showPinDialog = true
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ورود به فضای مخفی")
            .setSubtitle("اثر انگشت یا قفل صفحه")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    fun requestSecret() {
        secretUnlocked = false
        if (prefs.getString("pin", null) == null) {
            newPinMode = true
            pinInput = ""
            showPinDialog = true
        } else {
            newPinMode = false
            unlockWithBiometric()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Purple, secondary = Pink, background = Bg, surface = Panel
    )) {
        Box(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF1D1031), Bg, Color(0xFF08070D))))
                .pointerInput(Unit) {
                    awaitEachGesture {
                        var startY = mutableMapOf<androidx.compose.ui.input.pointer.PointerId, Float>()
                        var crossed = false
                        do {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.size >= 2) {
                                pressed.take(2).forEach { change ->
                                    if (change.id !in startY) startY[change.id] = change.position.y
                                }
                                val first = pressed[0]
                                val second = pressed[1]
                                val dy1 = first.position.y - (startY[first.id] ?: first.position.y)
                                val dy2 = second.position.y - (startY[second.id] ?: second.position.y)
                                if (!crossed && kotlin.math.abs(dy1) > 55f && kotlin.math.abs(dy2) > 55f && dy1 * dy2 < 0) {
                                    crossed = true
                                    requestSecret()
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Pink)), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(29.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("PLAYER MUSIC", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                        Text("YOUR SOUND. YOUR SPACE.", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = {
                        if (permissionGranted) kotlinx.coroutines.MainScope().launch { scanTracks() }
                        else permissionLauncher.launch(audioPermission())
                    }) { Icon(Icons.Default.Refresh, "به‌روزرسانی", tint = Muted) }
                }
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.fillMaxWidth().background(Color(0xFF211833), RoundedCornerShape(18.dp)).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Pink)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(if (secretUnlocked) "فضای مخفی باز است" else "فضای خودت، انتخاب خودت", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(if (secretUnlocked) "آهنگ‌های خصوصی و پلی‌لیست‌ها" else "برای ورود، حرکت دو انگشتی را انجام بده", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))

                AnimatedVisibility(visible = secretUnlocked, enter = fadeIn() + scaleIn(), exit = fadeOut()) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("SECRET SPACE", color = Pink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { secretUnlocked = false }) { Text("قفل کردن") }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = playlistName, onValueChange = { playlistName = it },
                                label = { Text("نام پلی‌لیست") }, singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            IconButton(onClick = { if (playlistName.isNotBlank()) {
                                playlistNames = (playlistNames + playlistName.trim()).distinct()
                                prefs.edit().putStringSet("playlists", playlistNames.toSet()).apply()
                                playlistName = ""
                                showPlaylistDialog = false
                            } }) { Icon(Icons.Default.AddCircle, "افزودن پلی‌لیست", tint = Pink) }
                        }
                        if (playlistNames.isNotEmpty()) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                playlistNames.take(3).forEach { name ->
                                    SuggestionChip(onClick = { statusText = "پلی‌لیست «$name» ساخته شده است." }, label = { Text(name) })
                                }
                            }
                        }
                        Text("آهنگ‌های خصوصی", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("از فهرست عادی، «⋮» کنار آهنگ را بزن و به فضای مخفی اضافه کن.", color = Muted, fontSize = 11.sp)
                        if (privateTracks.isEmpty()) Text("هنوز آهنگی اضافه نشده", color = Muted, modifier = Modifier.padding(vertical = 12.dp))
                        privateTracks.forEach { file ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, null, tint = Pink)
                                Spacer(Modifier.width(8.dp))
                                Text(file.nameWithoutExtension, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1)
                                IconButton(onClick = {
                                    player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                                    player.prepare()
                                    player.play()
                                    isPlaying = true
                                    activeTrack = null
                                    statusText = "در حال پخش آهنگ خصوصی"
                                }) { Icon(Icons.Default.PlayCircle, "پخش خصوصی", tint = Purple) }
                                IconButton(onClick = {
                                    file.delete()
                                    refreshPrivate()
                                }) { Icon(Icons.Default.Delete, "حذف", tint = Muted) }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }

                Text(if (secretUnlocked) "LIBRARY" else "YOUR LIBRARY", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                if (!permissionGranted) {
                    Text("برای نمایش آهنگ‌ها مجوز دسترسی به فایل‌های صوتی را بده.", color = Muted)
                    Button(onClick = { permissionLauncher.launch(audioPermission()) }) { Text("دادن مجوز") }
                } else {
                    val visibleTracks = tracks.filter { it.id.toString() !in hiddenIds }
                    if (visibleTracks.isEmpty()) {
                        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.MusicNote, null, tint = Purple, modifier = Modifier.size(48.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("هنوز آهنگی پیدا نشده", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("آهنگ‌های ذخیره‌شده روی گوشی اینجا نمایش داده می‌شوند.", color = Muted, fontSize = 12.sp)
                            }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(visibleTracks, key = { it.id }) { track ->
                                Row(
                                    Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Color(0xFF4C267A), Color(0xFF211633))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.MusicNote, null, tint = Pink)
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                                    }
                                    IconButton(onClick = { play(track) }) {
                                        Icon(if (activeTrack?.id == track.id && isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle, "پخش", tint = Purple, modifier = Modifier.size(30.dp))
                                    }
                                    IconButton(onClick = {
                                        try {
                                            val folder = File(context.filesDir, "secret").apply { mkdirs() }
                                            val fileName = track.title.replace(Regex("[^a-zA-Z0-9آ-ی _.-]"), "_").take(60) + "_" + track.id + ".audio"
                                            val destination = File(folder, fileName)
                                            context.contentResolver.openInputStream(track.uri)?.use { input ->
                                                FileOutputStream(destination).use { output -> input.copyTo(output) }
                                            } ?: throw Exception("Cannot read audio")
                                            hiddenIds = hiddenIds + track.id.toString()
                                            prefs.edit().putStringSet("hidden_ids", hiddenIds).apply()
                                            refreshPrivate()
                                            statusText = "آهنگ به فضای خصوصی برنامه کپی شد."
                                            Toast.makeText(context, "به فضای مخفی اضافه شد", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "کپی آهنگ انجام نشد", Toast.LENGTH_LONG).show()
                                        }
                                    }) { Icon(Icons.Default.MoreVert, "گزینه‌ها", tint = Muted) }
                                }
                            }
                        }
                    }
                }
                activeTrack?.let { track ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp).background(Color(0xFF26163A), RoundedCornerShape(18.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("NOW PLAYING", color = Pink, fontSize = 9.sp, letterSpacing = 1.5.sp)
                            Text(track.title, color = Color.White, maxLines = 1, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = {
                            if (player.isPlaying) { player.pause(); isPlaying = false }
                            else { player.play(); isPlaying = true }
                        }) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "پخش/مکث", tint = Color.White) }
                        IconButton(onClick = {
                            val idx = tracks.indexOfFirst { it.id == track.id }
                            if (idx >= 0 && idx + 1 < tracks.size) play(tracks[idx + 1])
                        }) { Icon(Icons.Default.SkipNext, "بعدی", tint = Color.White) }
                    }
                }
                Text(statusText, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(bottom = 8.dp))
            }

            if (showPinDialog) {
                AlertDialog(
                    onDismissRequest = { showPinDialog = false; pinInput = "" },
                    containerColor = Panel,
                    title = { Text(if (newPinMode) "ساخت رمز فضای مخفی" else "رمز فضای مخفی", color = Color.White) },
                    text = {
                        Column {
                            Text(if (newPinMode) "یک رمز حداقل ۴ رقمی انتخاب کن." else "رمزت را وارد کن یا پنجره اثر انگشت را امتحان کن.", color = Muted)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = pinInput, onValueChange = { pinInput = it.filter(Char::isDigit).take(12) },
                                label = { Text("رمز") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (newPinMode) {
                                if (pinInput.length >= 4) {
                                    prefs.edit().putString("pin", pinInput).apply()
                                    secretUnlocked = true
                                    showPinDialog = false
                                    statusText = "رمز ساخته شد."
                                } else statusText = "رمز باید حداقل ۴ رقم باشد."
                            } else {
                                if (pinInput == prefs.getString("pin", null)) {
                                    secretUnlocked = true
                                    showPinDialog = false
                                    statusText = "فضای مخفی باز شد."
                                } else statusText = "رمز اشتباه است."
                            }
                            pinInput = ""
                        }) { Text(if (newPinMode) "ساخت رمز" else "ورود") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showPinDialog = false; pinInput = "" }) { Text("لغو") }
                    }
                )
            }
        }
    }
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: android.content.Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED
